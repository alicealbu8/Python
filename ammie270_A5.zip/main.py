import UI.console

UI.console.run()