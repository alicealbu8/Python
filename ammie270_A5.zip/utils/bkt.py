# general form of backtracking and helper functions
def init():
    """
    Defines the initial value for each element from the result array
    It should be less than the lowest possible value.
    """
    return -1


def get_next(el):
    """
    Getting the next possible elem in the solution.
    :param solution: current solution
    :type: list
    :return: next value of the last element
    :rtype: int
    """
    return el + 1


def exists(solution):
    """
    Checking if the selected element exists.
    :param solution: current solution
    :type: list
    :return: True if the current value of the last element is a possible value, False otherwise
    :rtype: bool
    """
    pass


def is_consistent(solution):
    """
    Checking if the current solution (which can be a partial solution as well)
    is correct.
    :param solution: current solution
    :type: list
    :return: True if the current (partial) solution is correct, False otherwise
    :rtype: bool
    """
    # the solution is considered consistent if the last element added is not yet in the solution
    return not solution[-1] in solution[:-1]


def is_solution(solution):
    """
    Checking if the current partial solution is a final solution
    :param solution: current solution
    :type: list
    :return: True if the current solution is a final solution, False otherwise
    :rtype: bool
    """
    pass


def generate_all_solutions(solution, init=init, get_next=get_next, exists=exists,
                           is_consistent=is_consistent, is_solution=is_solution):
    solution.append(init())
    solution[-1] = get_next(solution(solution))
    while exists(solution):
        if is_consistent(solution):
            if is_solution(solution):
                yield solution[:]
            else:
                yield from generate_all_solutions(solution[:], init, get_next, exists, is_consistent, is_solution)
        solution[-1] = get_next(solution)